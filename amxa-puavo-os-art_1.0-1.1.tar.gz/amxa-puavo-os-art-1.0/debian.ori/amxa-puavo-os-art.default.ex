# Defaults for amxa-puavo-os-art initscript
# sourced by /etc/init.d/amxa-puavo-os-art
# installed at /etc/default/amxa-puavo-os-art by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
