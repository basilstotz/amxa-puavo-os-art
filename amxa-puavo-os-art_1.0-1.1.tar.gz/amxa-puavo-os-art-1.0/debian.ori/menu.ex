?package(amxa-puavo-os-art):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-puavo-os-art" command="/usr/bin/amxa-puavo-os-art"
